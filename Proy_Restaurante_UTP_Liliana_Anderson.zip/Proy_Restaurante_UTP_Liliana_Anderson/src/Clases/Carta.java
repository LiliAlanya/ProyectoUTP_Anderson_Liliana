/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

import java.util.List;

/**
 *
 * @author Sopnopriyo
 */
public class Carta {
    
   private List<Carta_productos> cartItems;
   private double totalPrice;

    public Carta(List<Carta_productos> cartItems, double totalPrice) {
        this.cartItems = cartItems;
        this.totalPrice = totalPrice;
    }

    public List<Carta_productos> getCartItems() {
        return cartItems;
    }

    public void setCartItems(List<Carta_productos> cartItems) {
        this.cartItems = cartItems;
    }
    
    public void addItemToCart(Carta_productos cartItem) {
        this.cartItems.add(cartItem);
    }

    public double getTotalPrice() {
        totalPrice = 0;
        cartItems.forEach((cartItem) -> {
            totalPrice += cartItem.getPrice();
        });
        return totalPrice;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    } 
}
