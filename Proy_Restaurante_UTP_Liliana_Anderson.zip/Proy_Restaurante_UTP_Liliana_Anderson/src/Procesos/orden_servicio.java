/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Procesos;

import java.util.ArrayList;
import Clases.Carta;
import Clases.Carta_productos;

/**
 *
 * @author Sopnopriyo
 */
public class orden_servicio {
    
    private Carta cart;
    
    public orden_servicio() {
        this.cart = new Carta(new ArrayList<>(), 0);
    }
    
    public void addToCart(Carta_productos cartItem) {
        this.cart.addItemToCart(cartItem);
    }
    
    public void clearCart() {
        this.cart = new Carta(new ArrayList<>(), 0);
    }
    
    public Carta getCart() {
        return this.cart;
    }
}
