/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Procesos;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import Componente_Funciones.Labor;
import Componente_Funciones.Eliminar_labor;
import Componente_Funciones.ActualizarLabor;
import Clases.Funcion;
/**
 *
 * @author Sopnopriyo
 */
public class servicio_labor {

    public servicio_labor() {
    }

    public List<Labor> getAll() {
        List<Labor> labourList = new ArrayList<>();
        try (Scanner scanner = new Scanner(new FileInputStream("storage/labour.txt"))) {
            while (scanner.hasNextLine()) {

                String labourLine = scanner.nextLine();

                String labourInfo[] = labourLine.split(",");

                Labor labor = new Labor(labourInfo[0], labourInfo[1], Double.parseDouble(labourInfo[2]));

                labourList.add(labor);
            }
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Eliminar_labor.class.getName()).log(Level.SEVERE, null, ex);
        }
        return labourList;
    }

    public void create(Labor labour) {
        try (PrintWriter pw = new PrintWriter(new FileOutputStream("storage/labour.txt", true))) {
            pw.println(labour.getId() + "," + labour.getName() + "," + labour.getSalary());
        } catch (FileNotFoundException ex) {
            Logger.getLogger(Labor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public synchronized boolean update(String sourceId, Labor updatedLabour) {
        // Read all the items
        List<Labor> labourList = getAll();

        int indexToUpdate = -1;
        for (int i = 0; i < labourList.size(); i++) {
            Labor labour = labourList.get(i);

            if (labour.getId().equalsIgnoreCase(sourceId)) {
                indexToUpdate = i;
            }
        }

        if (indexToUpdate == -1) {
           return false;
        }

        labourList.set(indexToUpdate, updatedLabour);

        try {
            Files.delete(Paths.get("storage/labour.txt"));
        } catch (IOException ex) {
            Logger.getLogger(ActualizarLabor.class.getName()).log(Level.SEVERE, null, ex);
        }

        try (PrintWriter pw = new PrintWriter(new FileOutputStream("storage/labour.txt"))) {
            labourList.forEach(labour -> {
                pw.println(labour.getId() + "," + labour.getName() + "," + labour.getSalary());
            });
        } catch (FileNotFoundException ex) {
            Logger.getLogger(ActualizarLabor.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return true;
    }

    public synchronized void delete(String labourID) {
        List<Labor> labourList = getAll();

        // find the labour to be deleted
        for (int i = 0; i < labourList.size(); i++) {

            Labor labour = labourList.get(i);

            if (labour.getId().equalsIgnoreCase(labourID)) {
                labourList.remove(labour);
            }
        }

        try {
            // Delete the entire file
            Files.delete(Paths.get("storage/labour.txt"));
        } catch (IOException ex) {
            Logger.getLogger(servicio_labor.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Create a new file and write new data into the file
        try (PrintWriter pw = new PrintWriter(new FileOutputStream("storage/labour.txt"))) {
            labourList.forEach(labour -> {
                pw.println(labour.getId() + "," + labour.getName() + "," + labour.getSalary());
            });
        } catch (FileNotFoundException ex) {
            Logger.getLogger(servicio_labor.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void create(Funcion labour) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public boolean update(String sourceId, Funcion updatedLabour) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
